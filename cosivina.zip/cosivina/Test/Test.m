clc,clear all,close all;

sim=Simulator();

sim.addElement(NeuralField('Deneme',[5 5],5,-5,4));

%runtimes = sim.runWithTimer(100);
% 
% 
[sim.elementLabels, num2cell(runtimes)]