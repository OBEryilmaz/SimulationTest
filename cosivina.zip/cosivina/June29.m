clear all;
close all;
clc;
%Pick the image for target selection
pwd = 'C:\Users\omer\Desktop\cosivina';

ImageNumber=2; % randi(6); % The image has a target in the middle
ImageName=sprintf('%d.png', ImageNumber);
targetImage = imread(ImageName);
[SizeX, SizeY, colour]=size(targetImage);
fieldSize=[SizeX, SizeY];
currentSelection = 1;
connectionValue = -2; %Amplitude for connection
tStimOn=20;
%%


% create simulator object
sim = Simulator();
% Load the image
sim.addElement(ModifiedImageLoader('target image',pwd,ImageName,fieldSize,currentSelection,[tStimOn, inf]));
% Create the Target Location Map "TL_map"
%(NeuralField(label, size, tau, h, beta));
sim.addElement(NeuralField('TL_map', fieldSize, 5, -.8, 4));

%   Odd Colour Units uRed and uGreen
%   SingleNeuronWithconnection(label, size, tau, h, beta, connection)
sim.addElement(SingleNeuronWithconnection('uRed', [1, 1], 5, -6, 4,connectionValue),'target image','inputForRed',...
    [],[]);
sim.addElement(SingleNeuronWithconnection('uGreen', [1, 1], 5, -6, 4,connectionValue),'target image','inputForGreen',...
    [],[]);


% Create inhibitory connections between the two neurons(uRed and uGreen).
sim.addConnection('uRed','connection','uGreen');
sim.addConnection('uGreen','connection','uRed');


%sim.addElement(GaussStimulus2D('stimulus 1', fieldSize, 5, 5, 1, fieldSize(:,1)/2, fieldSize(:,2)/2, true, false));
%sim.addElement(ModifiedGaussStimulus2D('stimulus 1', fieldSize, 5, 5, 1, 23, 61));
sim.addElement(ModifiedGaussStimulus2D('stimulus 1', fieldSize, 5, 5, 1, fieldSize(:,1)/2, fieldSize(:,2)/2));
sim.addElement(ModifiedGaussStimulus2D('stimulus 2', fieldSize, 15, 15, 1, fieldSize(:,1)/2, fieldSize(:,2)/2));



% Calculate the weighted summations of the colour maps in
% the "Preprocessing" unit
sim.addElement(Preprocessing('Preprocessing'));
sim.addConnection('target image','imageRed','Preprocessing');
sim.addConnection('target image','imageGreen','Preprocessing');
sim.addConnection('uRed','output','Preprocessing');
sim.addConnection('uGreen','output','Preprocessing');

%Output of the preprocessing unit is the input of the TL_map
sim.addConnection('Preprocessing','output','TL_map');

sim.addElement(modifiedConvolution('stimulus conv', fieldSize , 1 ,0 ), {'stimulus 1', 'TL_map'});

sim.addElement(NeuralField('field d', fieldSize, 5, -0.5, 4), {'stimulus conv','stimulus 2'});
sim.addElement(NeuralField('field v', fieldSize, 5, -0.5, 4),'field d');
% initialize the simulator
sim.init();

figure,set(gcf, 'units','normalized','outerposition',[0.2 0.2 0.6 0.6]);
for i = 1 : 60
    
    

    
    sim.step();

    % plot field activation again

    subplot(4,2,1),
    imshow(sim.getComponent('stimulus 1', 'output'));
    ylabel('H output'); title('hand position');


    subplot(4,2,2),
    imshow(sim.getComponent('TL_map', 'output'));
    ylabel('T output'); title('target location');

    subplot(4,2,3),
    imagesc(sim.getComponent('stimulus conv', 'output'));
    ylabel('Conv output(distance and velocity)');title('imagesc');
    
    subplot(4,2,4),
    imagesc(sim.getComponent('stimulus conv', 'output'));
    ylabel('Conv output(distance and velocity)');title('imshow');
    
    subplot(4,2,5),
    imagesc(sim.getComponent('field d', 'activation'));
    title('field d, activation');
    subplot(4,2,6),
    imagesc(sim.getComponent('field d', 'output'));
    title('field d, output');
    
    subplot(4,2,7),
    imagesc(sim.getComponent('field v', 'activation'));
    title('field v, activation');
    
    subplot(4,2,8),
    imagesc(sim.getComponent('field v', 'output'));
    title('field v, output');



    drawnow;

end

