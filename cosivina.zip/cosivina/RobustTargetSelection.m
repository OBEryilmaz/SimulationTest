% Robust Target Selection
% Image will be read after 10 steps
clear all;
close all;
clc;
%Pick the image for target selection
pwd = 'C:\Users\omer\Desktop\cosivina';
%randperm()
ImageNumber=2; % randi(6); % The image has a target in the middle
ImageName=sprintf('%d.png', ImageNumber);
targetImage = imread(ImageName);
[SizeX, SizeY, colour]=size(targetImage);
fieldSize=[SizeX, SizeY];
currentSelection = 1;
connectionValue = -2; %Amplitude for connections can be different for each one 
tStimOn=3;
%%
% create simulator object
sim = Simulator();

% Load the image
sim.addElement(ModifiedImageLoader('target image',pwd,ImageName,fieldSize,currentSelection,[tStimOn, inf]));

% Create the Target Location Map "TL_map"
%(NeuralField(label, size, tau, h, beta));
sim.addElement(NeuralField('TL_map', fieldSize, 5, -0.5, 4));

%   Odd Colour Units uRed and uGreen
%   SingleNeuronWithconnection(label, size, tau, h, beta, connection)
sim.addElement(SingleNeuronWithconnection('uRed', [1, 1], 5, -6, 4,connectionValue),'target image','inputForRed',...
    [],[]);
sim.addElement(SingleNeuronWithconnection('uGreen', [1, 1], 5, -6, 4,connectionValue),'target image','inputForGreen',...
    [],[]);


% Create inhibitory connections between the two neurons(uRed and uGreen).
sim.addConnection('uRed','connection','uGreen');
sim.addConnection('uGreen','connection','uRed');


sim.addElement(GaussStimulus2D('stimulus 1', fieldSize, 15, 15, 1, fieldSize(:,1)/2, fieldSize(:,2)/2, true, false));
sim.addElement(GaussStimulus2D('stimulus 2', fieldSize, 15, 15, 10, fieldSize(:,1)/2, fieldSize(:,2)/2, true, false));


% Calculate the weighted summations of the colour maps in
% the "Preprocessing" unit
sim.addElement(Preprocessing('Preprocessing'));
sim.addConnection('target image','imageRed','Preprocessing');
sim.addConnection('target image','imageGreen','Preprocessing');
sim.addConnection('uRed','output','Preprocessing');
sim.addConnection('uGreen','output','Preprocessing');

%Output of the preprocessing unit is the input of the TL_map
sim.addConnection('Preprocessing','output','TL_map');

sim.addElement(modifiedConvolution('stimulus conv', fieldSize , 1 ,0 ), {'stimulus 1', 'TL_map'});
sim.addElement(SumInputs('stimulus sum', fieldSize), {'stimulus 2','stimulus conv'});
%sim.addConnection('TL_map','output','stimulus sum');


% create neural field
sim.addElement(NeuralField('field d', fieldSize, 5, -5, 4), {'stimulus conv','stimulus 2'});
sim.addElement(NeuralField('field v', fieldSize, 5, -0.5, 4),'field d');

% % lateral interactions in 2D field for u ->u & u ->v
  sim.addElement(LateralInteractions2D('d -> d', fieldSize, 0, 0, 0, 0, 0, 0, -0.5), ...
       'field d', 'output', 'field d', 'output');
% %LateralInteractions2D(label, size, sigmaExcY, sigmaExcX, amplitudeExc, ...
% %     sigmaInhY, sigmaInhX, amplitudeInh, amplitudeGlobal)
 sim.addElement(LateralInteractions2D('d -> v', fieldSize, 0, 0, 0, 0, 0, 0, -0.05), ...
  'field d', 'output', 'field v', 'output');
 sim.addElement(LateralInteractions2D('v -> v', fieldSize, 0, 0, 0, 0, 0, 0, -0.05), ...
  'field v', 'output', 'field v', 'output');

% create noise stimulus and noise kernel
sim.addElement(NormalNoise('noise d', fieldSize, 1));
sim.addElement(GaussKernel2D('noise kernel d', fieldSize, 5, 5, true, true), 'noise d', 'output', 'field d');
sim.addElement(NormalNoise('noise v', fieldSize, 1));
sim.addElement(GaussKernel2D('noise kernel v', fieldSize, 5, 5, true, true), 'noise v', 'output', 'field v');
% initialize the simulator
sim.init();
h_uRed = sim.getElement('uRed');
h_uRed = h_uRed.output;
h_uGreen=sim.getElement('uGreen');
h_uGreen = h_uGreen.output;

figure,%set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 1, 0.96]);
output_uRed=[];
output_uGreen=[];
maxStep=20;
interestedPointsInput=zeros(SizeX,maxStep);
interestedPointsOutput=zeros(SizeX,maxStep);

for i = 1 : maxStep
    sim.step();
    h_uRed=sim.getComponent('uRed','output');
    h_uGreen=sim.getComponent('uGreen','output');
    output_uRed = [output_uRed, h_uRed];
    output_uGreen = [output_uGreen, h_uGreen];
    
    hSum=sim.getComponent('stimulus sum', 'output');
    interestedPointsInput(:,i)=hSum(:,61);
    hField_D=sim.getComponent('stimulus sum', 'output');
    interestedPointsOutput(:,i)=hField_D(:,61);

    % plot field activation again
    subplot(5,2,1),
    plot(interestedPointsInput,'b-'),hold on,plot(interestedPointsOutput,'r--');
    subplot(5,2,2),
    plot(output_uRed,'r-'),hold on, plot(output_uGreen,'g-'),legend('uR','uG');
    title('Red and Green Unit Activation')
    subplot(5,2,3),
    imshow(sim.getComponent('TL_map', 'activation'));
    title('TL_map Activation');
    
    subplot(5,2,4),
    TL_output=sim.getComponent('TL_map', 'output');
    
    imshow(TL_output);
    title('TL_map Output');
    
    subplot(5,2,5),
    imshow(sim.getComponent('field d', 'activation'));
    title('D activation');
    
    subplot(5,2,6),
    imshow(sim.getComponent('field d', 'output'));
    title('D Output');
    
    subplot(5,2,7),
    imshow(sim.getComponent('field v', 'activation'));
    title('V activation');

    subplot(5,2,8),
    imshow(sim.getComponent('field v', 'output'));colormap('gray')
    title('V output');
    
    drawnow;
    
end


