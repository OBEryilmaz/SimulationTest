clear all;
close all;
clc;
%Pick the image for target selection
pwd = 'C:\Users\omer\Desktop\CorLEGO\Cosivina\sschneegans-cosivina-b87edf055575';

ImageNumber=2; % randi(6); % The image has a target in the middle
ImageName=sprintf('%d.png', ImageNumber);
targetImage = imread(ImageName);
[SizeX, SizeY, colour]=size(targetImage);
fieldSize=[SizeX, SizeY];
currentSelection = 1;
connectionValue = -2; %Amplitude for connection
tStimOn=10;
%%


% create simulator object
sim = Simulator();
% Load the image
sim.addElement(ModifiedImageLoader('target image',pwd,ImageName,fieldSize,currentSelection,[tStimOn, inf]));
% Create the Target Location Map "TL_map"
%(NeuralField(label, size, tau, h, beta));
sim.addElement(NeuralField('TL_map', fieldSize, 5, -.5, 4));

%   Odd Colour Units uRed and uGreen
%   SingleNeuronWithconnection(label, size, tau, h, beta, connection)
sim.addElement(SingleNeuronWithconnection('uRed', [1, 1], 5, -6, 4,connectionValue),'target image','inputForRed',...
    [],[]);
sim.addElement(SingleNeuronWithconnection('uGreen', [1, 1], 5, -6, 4,connectionValue),'target image','inputForGreen',...
    [],[]);


% Create inhibitory connections between the two neurons(uRed and uGreen).
sim.addConnection('uRed','connection','uGreen');
sim.addConnection('uGreen','connection','uRed');


%sim.addElement(GaussStimulus2D('stimulus 1', fieldSize, 5, 5, 1, fieldSize(:,1)/2, fieldSize(:,2)/2, true, false));
%sim.addElement(ModifiedGaussStimulus2D('stimulus 1', fieldSize, 5, 5, 1, 23, 61));
sim.addElement(ModifiedGaussStimulus2D('stimulus 1', fieldSize, 5, 5, 1, fieldSize(:,1)/2, fieldSize(:,2)/2));




% Calculate the weighted summations of the colour maps in
% the "Preprocessing" unit
sim.addElement(Preprocessing('Preprocessing'));
sim.addConnection('target image','imageRed','Preprocessing');
sim.addConnection('target image','imageGreen','Preprocessing');
sim.addConnection('uRed','output','Preprocessing');
sim.addConnection('uGreen','output','Preprocessing');

%Output of the preprocessing unit is the input of the TL_map
sim.addConnection('Preprocessing','output','TL_map');

sim.addElement(ModifiedConvolution('stimulus conv', fieldSize , 1 ,0 ), {'stimulus 1', 'TL_map'});
% initialize the simulator
sim.init();

figure,set(gcf, 'units','normalized','outerposition',[0.2 0.2 0.6 0.6]);
for i = 1 : 30
    
    
%     hStim=sim.getElement('stimulus 1');
%     hStim.positionY  = hStim.positionY +1; 
%     hStim.init();
    
    sim.step();

    % plot field activation again

    subplot(2,2,1),
    imshow(sim.getComponent('stimulus 1', 'output'));
    ylabel('H output'); title('hand position');


    subplot(2,2,2),
    imshow(sim.getComponent('TL_map', 'output'));
    ylabel('T output'); title('target location');

    subplot(2,2,3),
    imagesc(sim.getComponent('stimulus conv', 'output'));
    ylabel('Conv output(distance and velocity)');title('imagesc');
    
    subplot(2,2,4),
    imshow(uint8(sim.getComponent('stimulus conv', 'output')));
    ylabel('Conv output(distance and velocity)');title('imshow');



    drawnow;

end

