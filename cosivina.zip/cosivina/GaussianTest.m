% Gauss Test
clc,clear all,close all;
fieldSize=100;

sim=Simulator();
% GaussStimulus1D(label, size, sigma, amplitude, position, circular, normalized)

sim.addElement(GaussStimulus1D('stim1',fieldSize,25,5,23,true,false));
sim.addElement(GaussStimulus1D('stim2',fieldSize,25,5,60,true,false));

sim.addElement(SumInputs('stim1+stim2',fieldSize),{'stim1','stim2'},{'output','output'});

sim.init();
for i=1:10
    sim.step();
end
figure
subplot(3,1,1)
plot(sim.getComponent('stim1','output'),'r-');
subplot(3,1,2)
plot(sim.getComponent('stim2','output'),'b-');
subplot(3,1,3)
plot(ans.elements{1, 3}.output,'g-');